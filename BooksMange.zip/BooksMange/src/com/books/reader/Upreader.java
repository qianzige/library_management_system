package com.books.reader;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Reader;
import com.books.service.ReaderDao;
@WebServlet("/Upreader")
public class Upreader extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("GBK");
        String id=request.getParameter("id");
        String reader_name=request.getParameter("reader_name");

        Reader reader=new Reader();
        reader.setId(Integer.parseInt(id));     
		reader.setReader_name(reader_name);
        ReaderDao readerDao=new ReaderDao();
        boolean result=readerDao.UpdateReader(reader);
        if(result){
        	request.setAttribute("result","修改成功！！！");
            response.sendRedirect("SeeReaders");
        }
    }

}
