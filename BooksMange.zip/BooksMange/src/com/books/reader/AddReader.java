package com.books.reader;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Reader;
import com.books.service.ReaderDao;

@WebServlet("/AddReader")
public class AddReader extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String reader_name=request.getParameter("reader_name");
		ReaderDao readerDao=new ReaderDao();
	

		Reader reader=new Reader();	
		reader.setReader_name(reader_name);		
		boolean result=readerDao.AddReader(reader);
		if(result){
			request.setAttribute("result","添加成功！！！");
		response.sendRedirect("SeeReaders");
		}
	}

}
