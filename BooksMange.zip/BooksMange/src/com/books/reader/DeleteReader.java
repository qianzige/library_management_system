package com.books.reader;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.service.LendsDao;
import com.books.service.ReaderDao;
import com.books.service.ReturnsDao;


@WebServlet("/DeleteReader")
public class DeleteReader extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String id=request.getParameter("id");
		ReaderDao readerDao=new ReaderDao();
		LendsDao lendsDao=new LendsDao();
		ReturnsDao returnsDao=new ReturnsDao();
		boolean result=readerDao.DeleteReader(Integer.parseInt(id));
		lendsDao.DeleteLendByReaderId(Integer.parseInt(id));
		returnsDao.DeleteReturnsByReaderId(Integer.parseInt(id));
		if(result){
			request.setAttribute("result","删除成功！！！");
			request.getRequestDispatcher("SeeReaders").forward(request, response);
		}
	}

}
