package com.books.reader;


import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Reader;
import com.books.service.ReaderDao;
@WebServlet("/SeeReaders")
public class SeeReaders extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
      this.doGet(request, response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("utf-8");
        int pageNum=1;
        int pageSize=5;
        if(request.getParameter("pageNum")!=null&&!request.getParameter("pageNum").equals("")) {
        	 pageNum=Integer.parseInt(request.getParameter("pageNum"));
        }
        if(request.getParameter("pageSize")!=null&&!request.getParameter("pageSize").equals("")) {
        	pageSize=Integer.parseInt(request.getParameter("pageSize"));
        }
        ReaderDao readerDao=new ReaderDao();
        ArrayList<Reader> list= null;
        int arr[] = readerDao.totalPage(pageSize);
       
            try {
                list = readerDao.PageAllReaders(pageNum,pageSize);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            request.setAttribute("pageNum", pageNum);
            request.setAttribute("tsum", arr[0]);//总个数
        	request.setAttribute("tpage", arr[1]);//总页数
            request.setAttribute("readers", list);
            request.getRequestDispatcher("/readerList.jsp").forward(request, response);   
    }
    
}
