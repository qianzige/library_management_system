package com.books.servlet;


import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Books;
import com.books.bean.Lends;
import com.books.service.BooksDao;
import com.books.service.LendsDao;
@WebServlet("/ToReturnBook")
public class ToReturnBook extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
      this.doGet(request, response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("utf-8");
        BooksDao booksDao=new BooksDao();
        ArrayList<Books> books=null;
        try {
        	books=booksDao.AllBooks();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
            request.setAttribute("books", books);
            request.getRequestDispatcher("/returnBook.jsp").forward(request, response);
    }
    
}
