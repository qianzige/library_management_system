package com.books.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Lends;
import com.books.bean.Returns;
import com.books.service.BooksDao;
import com.books.service.LendsDao;
import com.books.service.ReturnsDao;
import com.books.tools.UUIDGen;

@WebServlet("/ReturnBooks")
public class ReturnBooks extends HttpServlet {
	protected void doGett(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String id=request.getParameter("id");
		String reader=request.getParameter("reader");
		if(id.equals("")||id==null){
			request.setAttribute("result","未选择归还图书，归还失败！！！");
			request.getRequestDispatcher("SeeBooks").forward(request, response);
		}else{
		LendsDao lendsDao=new LendsDao();
		try {
			Lends lends=lendsDao.LendsByReaderIdAndBookId(reader,id);
			if(lends.getId()!=0){
					Returns returns=new Returns();
					returns.setBook_id(Integer.parseInt(id));
					Date d = new Date();   
			        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
			        String return_date = sdf.format(d);  
					returns.setReturn_date(return_date);
					returns.setSernum(new UUIDGen().generateShortUuid());
					returns.setReader_id(Integer.parseInt(reader));
					BooksDao booksDao=new BooksDao();
					ReturnsDao returnsDao=new ReturnsDao();			
					boolean result1=booksDao.AddStock(id);
					boolean result2=returnsDao.AddReturns(returns);
					boolean result3=lendsDao.DeleteLendByBookIdAndReaderId(id, reader);
					if(result1&&result2&&result3){
						request.setAttribute("result","归还成功！！！");
					request.getRequestDispatcher("SeeBooks").forward(request, response);
					}else{
						request.setAttribute("result","未知原因，归还失败！！！");
						request.getRequestDispatcher("SeeBooks").forward(request, response);
					}
			}else{
				request.setAttribute("result","当前读者未借阅此书，归还失败！！！");
				request.getRequestDispatcher("SeeBooks").forward(request, response);
			}
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
	}

}

