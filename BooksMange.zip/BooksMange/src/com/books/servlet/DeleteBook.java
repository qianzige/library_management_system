package com.books.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.service.BooksDao;
import com.books.service.LendsDao;
import com.books.service.ReturnsDao;


@WebServlet("/DeleteBook")
public class DeleteBook extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String id=request.getParameter("id");
		BooksDao booksDao=new BooksDao();
		LendsDao lendsDao=new LendsDao();
		ReturnsDao returnsDao=new ReturnsDao();
		boolean result=booksDao.DeleteBook(Integer.parseInt(id));
		lendsDao.DeleteLendByBook_id(Integer.parseInt(id));
		returnsDao.DeleteReturnsByBook_id(Integer.parseInt(id));
		if(result){
			request.setAttribute("result","删除成功！！！");
			request.getRequestDispatcher("SeeBooks").forward(request, response);
		}
	}

}
