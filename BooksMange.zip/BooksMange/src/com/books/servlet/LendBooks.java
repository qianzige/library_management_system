package com.books.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Lends;
import com.books.service.BooksDao;
import com.books.service.LendsDao;
import com.books.tools.UUIDGen;

@WebServlet("/lendbook")
public class LendBooks extends HttpServlet {
	protected void doGett(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("sada");
		request.setCharacterEncoding("utf-8");
		String id=request.getParameter("id");
		String stock=request.getParameter("stock");
		String reason=request.getParameter("reason");
		String reader=request.getParameter("reader");
		String return_date=request.getParameter("return_date");
		BooksDao booksDao=new BooksDao();
		LendsDao lendsDao=new LendsDao();
		Lends lend=new Lends();
		lend.setBook_id(Integer.parseInt(id));
		lend.setReason(reason);
		lend.setReturn_date(return_date);
		lend.setReader_id(Integer.parseInt(reader));
		Date d = new Date();   
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
        String lend_date = sdf.format(d);  
		lend.setLend_date(lend_date);
		lend.setSernum(new UUIDGen().generateShortUuid());
		
		if(Integer.parseInt(stock)>=1){
			try {
				Lends lends=lendsDao.LendsByReaderIdAndBookId(reader, id);
				if(lends.getId()==0){
					boolean result1=booksDao.UpdateStock(id);
					boolean result2=lendsDao.AddLend(lend);
					if(result1&&result2){
						request.setAttribute("result","借阅成功！！！");
					request.getRequestDispatcher("SeeBooks").forward(request, response);
					}else{
						request.setAttribute("result","未知原因，借阅失败！！！");
						request.getRequestDispatcher("SeeBooks").forward(request, response);
					}
				}else{
					request.setAttribute("result","不可重复借阅，借阅失败！！！");
					request.getRequestDispatcher("SeeBooks").forward(request, response);
				}
				
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			System.out.println(lend);
			request.setAttribute("result","借阅失败，图书库存不足！！！");
			request.getRequestDispatcher("SeeBooks").forward(request, response);
		}
	
	
	}

}

