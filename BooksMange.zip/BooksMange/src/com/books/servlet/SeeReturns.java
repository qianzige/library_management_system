package com.books.servlet;


import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Books;
import com.books.bean.Reader;
import com.books.bean.Returns;
import com.books.service.BooksDao;
import com.books.service.ReaderDao;
import com.books.service.ReturnsDao;
@WebServlet("/SeeReturns")
public class SeeReturns extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
      this.doGet(request, response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("utf-8");
        int pageNum=1;
        int pageSize=5;
        String book_name=request.getParameter("book_name")==null?"":request.getParameter("book_name");
        if(request.getParameter("pageNum")!=null&&!request.getParameter("pageNum").equals("")) {
        	 pageNum=Integer.parseInt(request.getParameter("pageNum"));
        }
        if(request.getParameter("pageSize")!=null&&!request.getParameter("pageSize").equals("")) {
        	pageSize=Integer.parseInt(request.getParameter("pageSize"));
        }
        ReturnsDao returnsDao=new ReturnsDao();
        BooksDao booksDao=new BooksDao();
        ReaderDao readerDao=new ReaderDao();
        ArrayList<Returns> list= null;
        ArrayList<Books> books=null;
        ArrayList<Reader> readers=null;
        try {
        	books=booksDao.AllBooks();
        	readers=readerDao.AllReaders();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        int arr[] = returnsDao.totalPage(pageSize);
        if(!book_name.equals("")){
            try {
                list = returnsDao.ReturnsByBookName(book_name,pageNum,pageSize);
                System.out.println("asdasdads"+list);
        		
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            request.setAttribute("pageNum", pageNum);//当前页
            request.setAttribute("tsum", arr[0]);//总个数
        	request.setAttribute("tpage", arr[1]);//总页数
            request.setAttribute("returns", list);
            request.setAttribute("readers", readers);
            request.setAttribute("books", books);
            request.getRequestDispatcher("/returnList.jsp").forward(request, response);
        }else {
            try {
                list = returnsDao.PageAllReturns(pageNum,pageSize);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            request.setAttribute("pageNum", pageNum);
            request.setAttribute("tsum", arr[0]);//总个数
        	request.setAttribute("tpage", arr[1]);//总页数
            request.setAttribute("returns", list);
            request.setAttribute("readers", readers);
            request.setAttribute("books", books);
            request.getRequestDispatcher("/returnList.jsp").forward(request, response);
        }
    }
    
}
