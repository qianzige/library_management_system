package com.books.servlet;


import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Books;
import com.books.bean.Lends;
import com.books.bean.Reader;
import com.books.service.BooksDao;
import com.books.service.LendsDao;
import com.books.service.ReaderDao;
@WebServlet("/SeeLends")
public class SeeLends extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
      this.doGet(request, response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("utf-8");
        int pageNum=1;
        int pageSize=5;
        String book_name=request.getParameter("book_name")==null?"":request.getParameter("book_name");
        if(request.getParameter("pageNum")!=null&&!request.getParameter("pageNum").equals("")) {
        	 pageNum=Integer.parseInt(request.getParameter("pageNum"));
        }
        if(request.getParameter("pageSize")!=null&&!request.getParameter("pageSize").equals("")) {
        	pageSize=Integer.parseInt(request.getParameter("pageSize"));
        }
        LendsDao lendsDao=new LendsDao();
        BooksDao booksDao=new BooksDao();
        ReaderDao readerDao=new ReaderDao();
        ArrayList<Lends> list= null;
        ArrayList<Books> books=null;
        ArrayList<Reader> readers=null;
        try {
        	books=booksDao.AllBooks();
        	readers=readerDao.AllReaders();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        int arr[] = lendsDao.totalPage(pageSize);
        if(!book_name.equals("")){
            try {
                list = lendsDao.LendsByBookName(book_name,pageNum,pageSize);
        		
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            request.setAttribute("pageNum", pageNum);//当前页
            request.setAttribute("tsum", arr[0]);//总个数
        	request.setAttribute("tpage", arr[1]);//总页数
            request.setAttribute("lends", list);
            request.setAttribute("readers", readers);
            request.setAttribute("books", books);
            request.getRequestDispatcher("/lendList.jsp").forward(request, response);
        }else {
            try {
                list = lendsDao.PageAllLends(pageNum,pageSize);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            request.setAttribute("pageNum", pageNum);
            request.setAttribute("tsum", arr[0]);//总个数
        	request.setAttribute("tpage", arr[1]);//总页数
            request.setAttribute("lends", list);
            request.setAttribute("readers", readers);
            request.setAttribute("books", books);
            request.getRequestDispatcher("/lendList.jsp").forward(request, response);
        }
    }
    
}
