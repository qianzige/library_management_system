package com.books.servlet;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Books;
import com.books.service.BooksDao;
@WebServlet("/Upbook")
public class Upbook extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("GBK");
        String id=request.getParameter("id");
        String book_name=request.getParameter("book_name");
		String author=request.getParameter("author");
		String type=request.getParameter("type");
		String price=request.getParameter("price");
		String book_press=request.getParameter("book_press");
		String stock=request.getParameter("stock");
		String details=request.getParameter("details");

        Books books=new Books();
        books.setId(Integer.parseInt(id));
        books.setAuthor(author);
		books.setBook_press(book_press);
		books.setPrice(Integer.parseInt(price));
		books.setType(type);
		books.setBook_name(book_name);
		books.setDetails(details);
		books.setStock(Integer.parseInt(stock));
        BooksDao booksDao=new BooksDao();
        boolean result=booksDao.UpdateBook(books);
        if(result){
        	request.setAttribute("result","修改成功！！！");
            response.sendRedirect("SeeBooks");
        }
    }

}
