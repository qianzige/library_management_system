package com.books.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.books.bean.Books;
import com.books.service.BooksDao;

@WebServlet("/AddBook")
public class AddBook extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String book_name=request.getParameter("book_name");
		String author=request.getParameter("author");
		String type=request.getParameter("type");
		String price=request.getParameter("price");
		String book_press=request.getParameter("book_press");
		String details=request.getParameter("details");
		String stock=request.getParameter("stock");
		BooksDao booksDao=new BooksDao();
	

		Books books=new Books();
		books.setAuthor(author);
		books.setBook_press(book_press);
		books.setPrice(Integer.parseInt(price));
		books.setType(type);
		books.setBook_name(book_name);
		books.setStock(Integer.parseInt(stock));
		books.setDetails(details);
		boolean result=booksDao.AddBook(books);
		if(result){
			request.setAttribute("result","添加成功！！！");
		response.sendRedirect("SeeBooks");
		}
	}

}
