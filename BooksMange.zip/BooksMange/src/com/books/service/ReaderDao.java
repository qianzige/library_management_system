package com.books.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.books.bean.Books;
import com.books.bean.Reader;
import com.books.tools.sqlTools;

public class ReaderDao {
	private sqlTools tools=new sqlTools();
	public int[] totalPage(int count) {     //返回数据总条数arr[0]和总页数arr[1]
		int arr[] = {0,1};
		Connection conn=null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = tools.getconn();
			String sql="select count(*) from reader";
				pstm = conn.prepareStatement(sql);
			
			rs = pstm.executeQuery();
			while(rs.next()) {
				arr[0] = rs.getInt(1);
			}
			if(arr[0] % count == 0) {
				arr[1] = arr[0] / count;
			}
			else {
				arr[1] = arr[0] / count + 1;
			}
			pstm.close();
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
	}finally {
		try {
			rs.close();
			pstm.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		return arr;
	}
	/**
     * 返回所有读者数据
     * @return
     * @throws SQLException
     */
    public ArrayList<Reader> AllReaders() throws SQLException {
        ArrayList<Reader> list=new ArrayList<Reader>();
        ResultSet rs=tools.Query("select *from reader");
        	while(rs.next()){
        		Reader reader=new Reader();
        		reader.setId(Integer.parseInt(rs.getString("id")));
        		reader.setReader_name(rs.getString("reader_name"));
				list.add(reader);
			}
        	rs.close();
        	return list;
    }
    /**
     * 返回所有读者数据
     * @return
     * @throws SQLException
     */
    public ArrayList<Reader> PageAllReaders(int pageNum,int pageSize) throws SQLException {
        ArrayList<Reader> list=new ArrayList<Reader>();
        ResultSet rs=tools.Query("select *from reader limit "+pageSize*(pageNum-1)+","+pageSize+"");
        	while(rs.next()){
        		Reader reader=new Reader();
        		reader.setId(Integer.parseInt(rs.getString("id")));
        		reader.setReader_name(rs.getString("reader_name"));  
				list.add(reader);
			}
        	rs.close();
        	return list;
    }
    /**
     * 获取一条读者信息
     * @return
     * @throws SQLException
     */
    public Reader ReaderById(String id) throws SQLException {
        ResultSet rs=tools.Query("select *from reader where id='"+id+"'");
    	Reader reader=new Reader();
        	if(rs.next()){
        		reader.setId(Integer.parseInt(rs.getString("id")));
        		reader.setReader_name(rs.getString("reader_name"));  
			}
        	rs.close();
        	return reader;
    }

    /**
     * 删除一条读者信息
     * @param id
     * @return
     */
    public boolean DeleteReader(Integer id){
        return tools.Update("delete from reader where id='"+id+"'")==1?true:false;
    }

    /**
     * 增加一条图书信息
     * @param stu
     * @return
     */
    public boolean AddReader(Reader reader){
        return tools.Update("insert into  reader(reader_name)" +
                " values('"+reader.getReader_name()+"')")==1?true:false;
    }

    /**
     * 修改一条读者信息
     * @param stu
     * @return
     */
    public boolean UpdateReader(Reader reader){
        return tools.Update("update reader set reader_name='" +reader.getReader_name()+"' where id='"+reader.getId()+"'")==1?true:false;
    }
}
