package com.books.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.books.bean.Users;
import com.books.tools.sqlTools;

public class UsersDao {
    private sqlTools tools=new sqlTools();

    /**
     * 登录
     * @param username
     * @param password
     * @return
     * @throws SQLException
     */
    public Users Login(String username,String password) throws SQLException {
        ResultSet rs=tools.Query("select *from users where username='"+username+"' and password='"+password+"'");
        Users users=new Users();
        if(rs.next()){
            users.setId(Integer.parseInt(rs.getString("id")));
            users.setUsername(rs.getString("username"));
            users.setPassword(rs.getString("password"));
        }
        return users;
    }

}
