package com.books.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.books.bean.Books;
import com.books.tools.sqlTools;

public class BooksDao {

    private sqlTools tools=new sqlTools();
	public int[] totalPage(int count) {     //返回数据总条数arr[0]和总页数arr[1]
		int arr[] = {0,1};
		Connection conn=null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = tools.getconn();
			String sql="select count(*) from books";
				pstm = conn.prepareStatement(sql);
			
			rs = pstm.executeQuery();
			while(rs.next()) {
				arr[0] = rs.getInt(1);
			}
			if(arr[0] % count == 0) {
				arr[1] = arr[0] / count;
			}
			else {
				arr[1] = arr[0] / count + 1;
			}
			pstm.close();
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
	}finally {
		try {
			rs.close();
			pstm.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		return arr;
	}
	/**
     * 返回所有图书数据
     * @return
     * @throws SQLException
     */
    public ArrayList<Books> AllBooks() throws SQLException {
        ArrayList<Books> list=new ArrayList<Books>();
        ResultSet rs=tools.Query("select *from books");
        	while(rs.next()){
        		Books books=new Books();
        		books.setId(Integer.parseInt(rs.getString("id")));
        		books.setBook_name(rs.getString("book_name"));
        		books.setBook_press(rs.getString("book_press"));
        		books.setAuthor(rs.getString("author"));
        		books.setPrice(Integer.parseInt(rs.getString("price")));
        		books.setType(rs.getString("type"));
        		books.setStock(rs.getInt("stock"));   
        		books.setDetails(rs.getString("details"));   
				list.add(books);
			}
        	rs.close();
        	return list;
    }
    /**
     * 返回所有图书数据
     * @return
     * @throws SQLException
     */
    public ArrayList<Books> PageAllBooks(int pageNum,int pageSize) throws SQLException {
        ArrayList<Books> list=new ArrayList<Books>();
        ResultSet rs=tools.Query("select *from books limit "+pageSize*(pageNum-1)+","+pageSize+"");
        	while(rs.next()){
        		Books books=new Books();
        		books.setId(Integer.parseInt(rs.getString("id")));
        		books.setBook_name(rs.getString("book_name"));
        		books.setBook_press(rs.getString("book_press"));
        		books.setAuthor(rs.getString("author"));
        		books.setPrice(Integer.parseInt(rs.getString("price")));
        		books.setType(rs.getString("type"));
        		books.setStock(rs.getInt("stock"));   
				list.add(books);
			}
        	rs.close();
        	return list;
    }

    /**
     * 模糊查询返回图书数据
     * @return
     * @throws SQLException
     */
    public ArrayList<Books> BooksByName(String book_name,int pageNum,int pageSize) throws SQLException {
        ArrayList<Books> list=new ArrayList<Books>();
        ResultSet rs=tools.Query("select *from books where book_name like '%"+book_name+"%' limit "+pageSize*(pageNum-1)+","+pageSize+"");
        while(rs.next()){
        	Books books=new Books();
            books.setId(Integer.parseInt(rs.getString("id")));
    		books.setBook_name(rs.getString("book_name"));
    		books.setBook_press(rs.getString("book_press"));
    		books.setAuthor(rs.getString("author"));
    		books.setPrice(Integer.parseInt(rs.getString("price")));
    		books.setType(rs.getString("type"));   
    		books.setStock(rs.getInt("stock"));   
    		books.setDetails(rs.getString("details"));   
    		list.add(books);
        }
        rs.close();
        return list;
    }

    /**
     * 获取一条图书信息
     * @return
     * @throws SQLException
     */
    public Books BookById(String id) throws SQLException {
        ResultSet rs=tools.Query("select *from books where id='"+id+"'");
        Books books=new Books();
        	if(rs.next()){
        		books.setId(Integer.parseInt(rs.getString("id")));
        		books.setBook_name(rs.getString("book_name"));
        		books.setBook_press(rs.getString("book_press"));
        		books.setAuthor(rs.getString("author"));
        		books.setPrice(Integer.parseInt(rs.getString("price")));
        		books.setType(rs.getString("type"));   
        		books.setStock(rs.getInt("stock"));   
        		books.setDetails(rs.getString("details"));   
			}
        	rs.close();
        	return books;
    }

    /**
     * 删除一条图书信息
     * @param id
     * @return
     */
    public boolean DeleteBook(Integer id){
        return tools.Update("delete from books where id='"+id+"'")==1?true:false;
    }

    /**
     * 增加一条图书信息
     * @param stu
     * @return
     */
    public boolean AddBook(Books book){
        return tools.Update("insert into  books(book_name,author,price,type,book_press,stock,details)" +
                " values('"+book.getBook_name()+"','"+book.getAuthor()+"','"+book.getPrice()+"','"+book.getType()
                +"','"+book.getBook_press()+"','"+book.getStock()+"','"+book.getDetails()+"')")==1?true:false;
    }

    /**
     * 修改一条图书信息
     * @param stu
     * @return
     */
    public boolean UpdateBook(Books book){
        return tools.Update("update books set book_name='" +book.getBook_name()+"',author='"+book.getAuthor()+"'," +
                "price='"+book.getPrice()+"',type='"+book.getType()+"',book_press='"+book.getBook_press()+"',stock='"+book.getStock()+"',details='"+book.getDetails()+"' where id='"+book.getId()+"'")==1?true:false;
    }
	public boolean UpdateStock(String id) {
		// TODO Auto-generated method stub
		 return tools.Update("update books set stock=stock-1 where id='"+id+"'")==1?true:false;

	}
	public boolean AddStock(String id) {
		// TODO Auto-generated method stub
		 return tools.Update("update books set stock=stock+1 where id='"+id+"'")==1?true:false;
	}
}
