package com.books.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.books.bean.Lends;
import com.books.tools.sqlTools;

public class LendsDao {

    private sqlTools tools=new sqlTools();
	/**
     * 增加一条借阅信息
     * @param stu
     * @return
     */
    public boolean AddLend(Lends lends){
        return tools.Update("insert into  lend_list(sernum,book_id,lend_date,return_date,reason,reader_id)" +
                " values('"+lends.getSernum()+"','"+lends.getBook_id()+"','"+lends.getLend_date()
                +"','"+lends.getReturn_date()+"','"+lends.getReason()
                +"',"+lends.getReader_id()+")")==1?true:false;
    }
    /**
     * 删除一条借阅信息
     * @param id
     * @return
     */
    public boolean DeleteLend(Integer id){
        return tools.Update("delete from lend_list where id='"+id+"'")==1?true:false;
    }
    /**
     * 通过书籍id和读者id删除一条借阅信息
     * @param id
     * @return
     */
    public boolean DeleteLendByBookIdAndReaderId(String book_id,String reader_id){
    	return tools.Update("delete from lend_list where book_id='"+book_id+"' and reader_id='"+reader_id+"'")==1?true:false;
    }
    /**
     * 删除某一读者借阅信息
     * @param id
     * @return
     */
    public boolean DeleteLendByReaderId(Integer readerId){
    	return tools.Update("delete from lend_list where reader_id='"+readerId+"'")>1?true:false;
    }
    /**
     * 删除与某书相关的借阅信息
     * @param id
     * @return
     */
    public boolean DeleteLendByBook_id(Integer id){
        return tools.Update("delete from lend_list where book_id='"+id+"'")>1?true:false;
    }
	public int[] totalPage(int count) {     //返回数据总条数arr[0]和总页数arr[1]
		int arr[] = {0,1};
		Connection conn=null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = tools.getconn();
			String sql="select count(*) from lend_list";
				pstm = conn.prepareStatement(sql);
			
			rs = pstm.executeQuery();
			while(rs.next()) {
				arr[0] = rs.getInt(1);
			}
			if(arr[0] % count == 0) {
				arr[1] = arr[0] / count;
			}
			else {
				arr[1] = arr[0] / count + 1;
			}
			pstm.close();
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
	}finally {
		try {
			rs.close();
			pstm.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		return arr;
	}
	/**
     * 返回所有借阅数据
     * @return
     * @throws SQLException
     */
    public ArrayList<Lends> PageAllLends(int pageNum,int pageSize) throws SQLException {
        ArrayList<Lends> list=new ArrayList<Lends>();
        ResultSet rs=tools.Query("select *from lend_list limit "+pageSize*(pageNum-1)+","+pageSize+"");
        	while(rs.next()){
        		Lends lends=new Lends();
	        	lends.setId(Integer.parseInt(rs.getString("id")));
	        	lends.setSernum(rs.getString("sernum"));
	        	lends.setBook_id(Integer.parseInt(rs.getString("book_id")));
	    		lends.setReason(rs.getString("reason"));
	    		lends.setLend_date(rs.getString("lend_date"));
	    		lends.setReturn_date(rs.getString("return_date"));  
	    		lends.setReader_id(rs.getInt("reader_id"));   
	    		
	    		list.add(lends);
			}
        	rs.close();
        	return list;
    }
	 /**
     * 模糊查询返回借阅数据
     * @return
	 * @throws NumberFormatException 
     * @throws SQLException
     */
	public ArrayList<Lends> LendsByBookName(String book_name, int pageNum, int pageSize) throws NumberFormatException, SQLException {
		
	        ArrayList<Lends> list=new ArrayList<Lends>();
	        ResultSet rs=tools.Query("select *from lend_list where book_id in (select id from books where book_name like '%"+book_name+"%') limit "+pageSize*(pageNum-1)+","+pageSize+"");
	        while(rs.next()){
	        	Lends lends=new Lends();
	        	lends.setId(Integer.parseInt(rs.getString("id")));
	        	lends.setSernum(rs.getString("sernum"));
	        	lends.setBook_id(Integer.parseInt(rs.getString("book_id")));
	    		lends.setReason(rs.getString("reason"));
	    		lends.setLend_date(rs.getString("lend_date"));
	    		lends.setReturn_date(rs.getString("return_date"));   
	    		lends.setReader_id(rs.getInt("reader_id"));   
	    		list.add(lends);
	        }
	        rs.close();
	        return list;
	}
	public Lends LendsByReaderIdAndBookId(String reader, String id) throws NumberFormatException, SQLException {
		ResultSet rs=tools.Query("select *from lend_list where book_id='"+id+"' and reader_id='"+reader+"'");
		Lends lends=new Lends();
		while(rs.next()){
	        	lends.setId(Integer.parseInt(rs.getString("id")));
	        	lends.setSernum(rs.getString("sernum"));
	        	lends.setBook_id(Integer.parseInt(rs.getString("book_id")));
	    		lends.setReason(rs.getString("reason"));
	    		lends.setLend_date(rs.getString("lend_date"));
	    		lends.setReturn_date(rs.getString("return_date"));   
	    		lends.setReader_id(rs.getInt("reader_id"));   
	        }
		return lends;
	}
}
