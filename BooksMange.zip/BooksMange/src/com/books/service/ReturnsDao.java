package com.books.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.books.bean.Lends;
import com.books.bean.Returns;
import com.books.tools.sqlTools;

public class ReturnsDao {

    private sqlTools tools=new sqlTools();
	/**
     * 增加一条归还记录
     * @param stu
     * @return
     */
    public boolean AddReturns(Returns returns){
        return tools.Update("insert into  return_list(sernum,book_id,return_date,reader_id)" +
                " values('"+returns.getSernum()+"','"
        		+returns.getBook_id()+"','"+returns.getReturn_date()+"','"+returns.getReader_id()+"')")==1?true:false;
    }
    /**
     * 删除一条归还信息
     * @param id
     * @return
     */
    public boolean DeleteReturns(Integer id){
        return tools.Update("delete from return_list where id='"+id+"'")==1?true:false;
    }
    /**
     * 删除某一读者归还信息
     * @param id
     * @return
     */
    public boolean DeleteReturnsByReaderId(Integer readerId){
    	return tools.Update("delete from return_list where reader_id='"+readerId+"'")>1?true:false;
    }
	public int[] totalPage(int count) {     //返回数据总条数arr[0]和总页数arr[1]
		int arr[] = {0,1};
		Connection conn=null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = tools.getconn();
			String sql="select count(*) from return_list";
				pstm = conn.prepareStatement(sql);
			
			rs = pstm.executeQuery();
			while(rs.next()) {
				arr[0] = rs.getInt(1);
			}
			if(arr[0] % count == 0) {
				arr[1] = arr[0] / count;
			}
			else {
				arr[1] = arr[0] / count + 1;
			}
			pstm.close();
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
	}finally {
		try {
			rs.close();
			pstm.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		return arr;
	}
	/**
     * 返回所有借阅数据
     * @return
     * @throws SQLException
     */
    public ArrayList<Returns> PageAllReturns(int pageNum,int pageSize) throws SQLException {
        ArrayList<Returns> list=new ArrayList<Returns>();
        ResultSet rs=tools.Query("select *from return_list limit "+pageSize*(pageNum-1)+","+pageSize+"");
        	while(rs.next()){
        		Returns returns=new Returns();
        		returns.setId(Integer.parseInt(rs.getString("id")));
        		returns.setSernum(rs.getString("sernum"));
        		returns.setBook_id(Integer.parseInt(rs.getString("book_id")));
	    		returns.setReturn_date(rs.getString("return_date"));   
	    		returns.setReader_id(rs.getInt("reader_id"));   
	    		list.add(returns);
			}
        	rs.close();
        	return list;
    }
    /**
     * 删除与某书相关的归还信息
     * @param id
     * @return
     */
    public boolean DeleteReturnsByBook_id(Integer id){
        return tools.Update("delete from return_list where book_id='"+id+"'")>1?true:false;
    }
	 /**
     * 模糊查询返回归还数据
     * @return
	 * @throws NumberFormatException 
     * @throws SQLException
     */
	public ArrayList<Returns> ReturnsByBookName(String book_name, int pageNum, int pageSize) throws NumberFormatException, SQLException {
		
	        ArrayList<Returns> list=new ArrayList<Returns>();
	        ResultSet rs=tools.Query("select *from return_list where book_id in (select id from books where book_name like '%"+book_name+"%') limit "+pageSize*(pageNum-1)+","+pageSize+"");
	        while(rs.next()){
	        	Returns returns=new Returns();
        		returns.setId(Integer.parseInt(rs.getString("id")));
        		returns.setSernum(rs.getString("sernum"));
        		returns.setBook_id(Integer.parseInt(rs.getString("book_id")));
	    		returns.setReturn_date(rs.getString("return_date"));   
	    		returns.setReader_id(rs.getInt("reader_id"));   
	    		list.add(returns);
	        }
	        rs.close();
	        return list;
	}
}
