package com.books.tools;

import com.books.bean.Users;

import java.io.BufferedWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;





public class sqlTools {
    public Connection getconn(){
    	Connection conn=null;
    	try{
    		String url="jdbc:mysql://localhost:3306/book?useSSL=false&serverTimezone=UTC";
    		Class.forName("com.mysql.jdbc.Driver");
    		conn=DriverManager.getConnection(url,"root","123456");
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return conn;
    }


	public ResultSet  Query(String sql){
		Connection conn=getconn();
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);

		}catch(Exception e){
			e.printStackTrace();
		}
		return rs;
	}
    public int Update(String sql){
    	Connection conn=getconn();
    	Statement stmt=null;
    	int sum=0;
    	try{
    		stmt=conn.createStatement();
    		sum=stmt.executeUpdate(sql);
    	}catch(Exception e){
    		e.printStackTrace();
    	}finally{
    		try {
    			stmt.close();
    			conn.close();
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    	}
    	return sum;
    }
}
