package com.books.bean;

public class Books {
	private int id;
	private String book_name;
	private String author;
	private int price;
	private String type;
	private String book_press;//出版社
	private String details;//出版社
	private int stock;
	private int is_lend;
	
	
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	@Override
	public String toString() {
		return "Books [id=" + id + ", book_name=" + book_name + ", author=" + author + ", price=" + price + ", type="
				+ type + ", book_press=" + book_press + ", stock=" + stock + ", is_lend=" + is_lend + "]";
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public int getIs_lend() {
		return is_lend;
	}
	public void setIs_lend(int is_lend) {
		this.is_lend = is_lend;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getBook_press() {
		return book_press;
	}
	public void setBook_press(String book_press) {
		this.book_press = book_press;
	}
	
}
