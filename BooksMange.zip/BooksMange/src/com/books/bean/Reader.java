package com.books.bean;

public class Reader {
	private int id;
	private String reader_name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getReader_name() {
		return reader_name;
	}
	public void setReader_name(String reader_name) {
		this.reader_name = reader_name;
	}
	@Override
	public String toString() {
		return "Reader [id=" + id + ", reader_name=" + reader_name + "]";
	}
	
}
